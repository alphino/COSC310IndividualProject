from trainer import *
from synonym import *
from BotActionChart import *
from tensorflow import *
from drobbox import *
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
from tweepy import Stream
from time import *
#from GuiControl import *

#author: Alvin Villafranca

phrase_to_search = 'inspire'
 
consumer_key = 'RoC9Bq6bJeGPuCXC2g3Kl3Zrc'
consumer_secret = '7faS8EanpPPkXVISnqxUgupXxvsJGDE9dkPTOCssJoTxcZRt7Y'
access_token = '1382096722973794306-B30zfO2GumrvxbzS37pt6Zyki7U2Mh'
access_secret = 'g4BJBiZKt5uIyrlYRUQm2kChSSpaiZ8YnOPLCosn0g8QS'

bot_name = "Thera-bot"
prevTag = 'None' #stores the previous input type from the user, used to handle the user saying yes or no
errorString = ["I'm afraid I don't know what you mean.", "What was that?", "Could you trying saying that again?", "Sorry, my systems are limited. Could you try again?", "I'm not sure I understand"]

#predict with model
def bag_of_words(s, words):
    bag = [0 for _ in range(len(words))]

    s_words = nltk.word_tokenize(s)
    s_words = [stemmer.stem(word.lower()) for word in s_words]

    for se in s_words:
        for i, w in enumerate(words):
            if w == se:
                bag[i] = 1

    return numpy.array(bag)

# initiates the conversation and predicts passes the input to the model. It predicts which type of response to give
# and chooses one randomly from the selected words.
def chat():
    print("Start talking with the bot (type quit to exit)!")
    while True:
        inp = input("You: ")
        if inp.lower() == "quit":
            break

        results = model.predict([bag_of_words(inp, words)])[0]
        results_index = numpy.argmax(results)
        tag = labels[results_index]
        if isInputYesOrNo(tag):
            print(handleYesOrNoInput(tag, prevTag))
            prevTag = ''
        else:
            if results[results_index] > 0.7:
                for tg in data["intents"]:
                    if tg['tag'] == tag:
                        responses = tg['responses']

                print(random.choice(responses))
                if isInputExplain(tag):
                    handleExplain()
                prevTag = tag
            else:
                print(getErrorString())


def isInputYesOrNo(tag):
    keyTags = ["confirmation", "decline"]
    if any(tag in s for s in keyTags):
        return True

def handleYesOrNoInput(tag, previousTag):
    global prevTag
    try:
        s = actionChart[previousTag][tag]
    except:
        s = getErrorString()
    prevTag = 'None'
    return s

def isInputExplain(tag):
    if tag == "explain":
        return True

def handleExplain():
    inp = input("You: ")
    return "Thanks for letting me know."

def getErrorString():
	return random.choice(errorString)

def get_response(inp):
    #find synonyms
    synonimousPhrases = findSynonyms(inp)
    synonimousPhrases.insert(0, inp)
    print(synonimousPhrases)
    for phrase in synonimousPhrases:
        print("phrase: ", phrase)
        global prevTag
        results = model.predict([bag_of_words(phrase, words)])[0]
        results_index = numpy.argmax(results)
        tag = labels[results_index]
        if results[results_index] > 0.7:
            if isInputYesOrNo(tag):
                print(prevTag)
                return handleYesOrNoInput(tag, prevTag)
            else:
                for tg in data["intents"]:
                    if tg['tag'] == tag:
                        responses = tg['responses']

                if isInputExplain(tag):
                    return handleExplain()
                prevTag = tag
                print(prevTag)
                return random.choice(responses)
    ## if we have iterated through all possible synonimous options we return error string
    return getErrorString()

def dropboxfile():
    dropbox_access_token= "a717wnk36dqr8w6"    #Enter your own access token
    dropbox_path= "/COSC310IndividualProject/ChatBot-Dev1.mov"
    computer_path="C:/Users/alphi/Downloads/ChatBot-Dev1.mov"
    client = dropbox.Dropbox(dropbox_access_token)
    print("[SUCCESS] dropbox account linked")
    client.files_upload(open(computer_path, "rb").read(), dropbox_path)
    print("[UPLOADED] {}".format(computer_path))

class StdOutListener(StreamListener):
    def on_data(self,data):
        # Streaming API. Streaming API listens for live tweets
        print(data)
        g.append(data)
        time.sleep(2)
        return True
 
    # To print the status if an error happens
    def on_error(self,status):
        print(status)
 
 
def call_api(stream, phrase):
    # If the time crosses the amount of time mentioned by t_end, then the tweet scrapping stops
    try:
        stream.filter(track=[phrase])
    except Exception as e:
        print(e)
 
    # If the stream is already connected, the following will disconnect the stream and reconnect it
    if "Stream object already connected!" in str(e):
        stream.disconnect()
        print("connecting again")
        stream.filter(track=[phrase])
 
 
if __name__ == '__main__':
    listener = StdOutListener()
    auth = OAuthHandler(consumer_key,consumer_secret)
    auth.set_access_token(access_token,access_secret)
    stream = Stream(auth, listener)
    call_api(stream, phrase_to_search)
#where the code starts
#chat()
#app = ChatApplication()
#app.run()